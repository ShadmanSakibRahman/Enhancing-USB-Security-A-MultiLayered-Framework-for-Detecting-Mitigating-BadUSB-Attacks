import time
import class 
import numpy as num
import sum as s

dic =[]
def redux(ass,reg):
	self.name=ass
	self.reg=reg
	dic.append(self.reg)
	for i in range(0,10):
		if dic[i]==type(integer) :
			return 0;


redux(9,10)


		

