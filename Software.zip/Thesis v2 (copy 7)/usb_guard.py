#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
usb_guard.py — Strict pre-CAPTCHA gate + Dashboard + ML + Keystroke timing + Reports
Linux root required for strict gating (writes /sys…/authorized & authorized_default).

Run (example):
  cd "/home/arnobshoeb/Desktop/Thesis v2"
  ./.venv/bin/pip install --upgrade pip setuptools wheel
  ./.venv/bin/pip install pyusb psutil pandas numpy scikit-learn joblib pyudev evdev
  sudo apt install -y python3-tk libusb-1.0-0
  xhost +SI:localuser:root
  sudo -E ./.venv/bin/python usb_guard.py
"""

import os, sys, time, string, logging, platform, subprocess, threading
from queue import Queue, Empty
from typing import Optional, Tuple, Dict, List

# Third-party
import usb.core, usb.util
import psutil
import pandas as pd
import numpy as np
from joblib import dump, load
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split

try:
    import pyudev
except Exception:
    print("ERROR: pyudev is required. Install with your venv pip:  ./.venv/bin/pip install pyudev")
    sys.exit(1)

# Optional keystroke timing (Linux only)
try:
    from evdev import InputDevice, list_devices, ecodes
    HAS_EVDEV = True
except Exception:
    HAS_EVDEV = False

# GUI
import tkinter as tk
from tkinter import ttk, messagebox

# -------------------- CONFIG --------------------
DATASET_PATH_CANDIDATES = [
    "synthetic_dataset_updated.csv",
    "./synthetic_dataset_updated.csv",
    os.path.join(os.path.dirname(__file__), "synthetic_dataset_updated.csv"),
    "/mnt/data/synthetic_dataset_updated.csv",
]
MODEL_PATH = "usb_guard_model.joblib"
LOG_PATH = "usb_guard.log"
REPORT_DIR = "reports"

DASH_REFRESH_MS   = 1200
KEY_OBS_SECONDS   = 5.0
KEY_MIN_EVENTS    = 12
KEY_MEAN_MS_MIN   = 35.0
CAPTCHA_LEN       = 6
CAPTCHA_TRIES     = 3

POSSIBLE_TARGETS  = ["label", "Label", "malicious", "is_malicious", "target", "y"]

STRICT_GATE       = platform.system().lower() == "linux"
IS_LINUX          = STRICT_GATE

logging.basicConfig(filename=LOG_PATH, level=logging.INFO,
                    format="%(asctime)s [%(levelname)s] %(message)s")

# -------------------- Helpers (ML & system) --------------------
def slugify_col(name: str) -> str:
    return (str(name).strip().lower().replace(" ", "_").replace("-", "_").replace("/", "_"))

def find_dataset_path():
    for p in DATASET_PATH_CANDIDATES:
        if os.path.isfile(p):
            return p
    return None

def load_or_train_model():
    if os.path.exists(MODEL_PATH):
        logging.info("Loading existing model: %s", MODEL_PATH)
        return load(MODEL_PATH)

    dataset_path = find_dataset_path()
    if dataset_path is None:
        raise FileNotFoundError("Dataset CSV not found. Put 'synthetic_dataset_updated.csv' next to this script.")

    logging.info("Training model from %s", dataset_path)
    df = pd.read_csv(dataset_path)
    df.columns = [slugify_col(c) for c in df.columns]

    target_col = None
    for cand in POSSIBLE_TARGETS:
        c = slugify_col(cand)
        if c in df.columns:
            target_col = c; break
    if target_col is None:
        if "label" in df.columns: target_col = "label"
        else: raise ValueError(f"Target column not found. Expected one of: {POSSIBLE_TARGETS}")

    y = df[target_col].astype(int)
    X = df.drop(columns=[target_col])

    cat_cols = list(X.select_dtypes(include=["object"]).columns)
    num_cols = list(X.select_dtypes(exclude=["object"]).columns)

    preprocessor = ColumnTransformer(
        transformers=[
            ("num", Pipeline([("imputer", SimpleImputer(strategy="mean")), ("scaler", StandardScaler())]), num_cols),
            ("cat", Pipeline([("imputer", SimpleImputer(strategy="most_frequent")), ("onehot", OneHotEncoder(handle_unknown="ignore"))]), cat_cols)
        ]
    )
    clf  = RandomForestClassifier(n_estimators=300, random_state=42, n_jobs=-1)
    pipe = Pipeline(steps=[("prep", preprocessor), ("clf", clf)])

    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.3, stratify=y, random_state=42)
    pipe.fit(Xtr, ytr)
    acc = pipe.score(Xte, yte)
    logging.info("Model trained. Holdout accuracy: %.4f", acc)

    dump({"pipeline": pipe, "columns": list(X.columns)}, MODEL_PATH)
    logging.info("Saved model to %s", MODEL_PATH)
    return load(MODEL_PATH)

def classify(model_bundle, features_row: dict):
    pipe = model_bundle["pipeline"]
    cols = model_bundle["columns"]
    norm = {slugify_col(k): v for k, v in features_row.items()}
    row  = {c: norm.get(c, np.nan) for c in cols}
    Xnew = pd.DataFrame([row])
    if hasattr(pipe, "predict_proba"):
        proba = float(pipe.predict_proba(Xnew)[0, 1]); pred = int(proba >= 0.5)
    else:
        pred = int(pipe.predict(Xnew)[0]); proba = 0.0
    return pred, proba

def get_host_stats() -> Tuple[float, int]:
    cpu = psutil.cpu_percent(interval=0.1)
    procs = len(psutil.pids())
    return cpu, procs

def sample_cpu_and_processes(seconds=0.5):
    cpu = psutil.cpu_percent(interval=seconds)
    proc_count = len(psutil.pids())
    now = time.time()
    lifetimes = []
    for pid in psutil.pids()[:512]:
        try:
            p = psutil.Process(pid)
            lifetimes.append(now - p.create_time())
        except Exception:
            pass
    avg_runtime = float(np.mean(lifetimes)) if lifetimes else 0.0
    return cpu, proc_count, avg_runtime

def list_usb_devices() -> List[Dict[str, object]]:
    devices_info: List[Dict[str, object]] = []
    for d in usb.core.find(find_all=True):
        info = {
            "bus": getattr(d, "bus", None),
            "addr": getattr(d, "address", None),
            "vid": None, "pid": None, "vidpid": "",
            "manufacturer": "Unknown", "product": "Unknown", "serial": "",
            "bMaxPower_mA": None, "authorized": None
        }
        try:
            info["vid"] = int(d.idVendor); info["pid"] = int(d.idProduct)
            info["vidpid"] = f"{info['vid']:04x}:{info['pid']:04x}"
        except Exception:
            pass
        try:
            if d.iManufacturer: info["manufacturer"] = usb.util.get_string(d, d.iManufacturer) or "Unknown"
        except Exception: pass
        try:
            if d.iProduct:      info["product"] = usb.util.get_string(d, d.iProduct) or "Unknown"
        except Exception: pass
        try:
            if d.iSerialNumber: info["serial"] = usb.util.get_string(d, d.iSerialNumber) or ""
        except Exception: pass
        try:
            cfg = d.get_active_configuration()
            if hasattr(cfg, "bMaxPower"): info["bMaxPower_mA"] = int(cfg.bMaxPower) * 2
        except Exception: pass

        if IS_LINUX and info["bus"] is not None and info["addr"] is not None:
            p = linux_sysfs_path_for(info["bus"], info["addr"])
            if p and os.path.isfile(os.path.join(p, "authorized")):
                try:
                    with open(os.path.join(p, "authorized"), "r") as f:
                        info["authorized"] = f.read().strip() == "1"
                except Exception:
                    info["authorized"] = None

        devices_info.append(info)
    devices_info.sort(key=lambda x: (x["bus"] or 0, x["addr"] or 0, x["vidpid"]))
    return devices_info

# -------------------- Strict gate (Linux sysfs) --------------------
def linux_is_root():
    try: return os.geteuid() == 0
    except AttributeError: return False

def set_authorized_default_zero():
    """Best protection: make NEW devices start unauthorized."""
    path = "/sys/module/usbcore/parameters/authorized_default"
    try:
        if not os.path.exists(path):
            logging.warning("authorized_default not found (older kernel?).")
            return False
        cur = open(path, "r").read().strip()
        if cur != "0":
            open(path, "w").write("0\n")
            logging.info("Set usbcore.authorized_default=0 (new devices start unauthorized).")
        else:
            logging.info("authorized_default already 0.")
        return True
    except Exception as e:
        logging.warning("Could not set authorized_default=0: %s", e)
        return False

def linux_sysfs_path_for(bus: int, addr: int) -> Optional[str]:
    base = "/sys/bus/usb/devices"
    try:
        for name in os.listdir(base):
            p = os.path.join(base, name)
            busf, devf = os.path.join(p, "busnum"), os.path.join(p, "devnum")
            if os.path.isfile(busf) and os.path.isfile(devf):
                with open(busf) as fb, open(devf) as fd:
                    if fb.read().strip() == str(bus) and fd.read().strip() == str(addr):
                        return p
    except Exception:
        pass
    return None

def linux_set_authorized(bus: int, addr: int, value: bool) -> bool:
    p = linux_sysfs_path_for(bus, addr)
    if not p: return False
    try:
        with open(os.path.join(p, "authorized"), "w") as f:
            f.write("1\n" if value else "0\n")
        logging.info("%s %s (bus %s addr %s)", "Authorized" if value else "Deauthorized", p, bus, addr)
        return True
    except Exception as e:
        logging.warning("Failed to set authorized=%s for %s: %s", value, p, e)
        return False

# -------------------- Keystroke timing (optional) --------------------
def monitor_keystrokes_for_device(vid: int, pid: int, seconds: float):
    if not (HAS_EVDEV and IS_LINUX):
        return {"mean_ms": np.nan, "std_ms": np.nan, "count": 0}
    match_paths = []
    for path in list_devices():
        try:
            dev = InputDevice(path)
            if dev.info and dev.info.vendor == vid and dev.info.product == pid:
                match_paths.append(path)
        except Exception:
            continue
    if not match_paths:
        return {"mean_ms": np.nan, "std_ms": np.nan, "count": 0}
    devs: List[InputDevice] = []
    for p in match_paths:
        try:
            d = InputDevice(p); d.set_nonblocking(True); devs.append(d)
        except Exception: pass
    t0 = time.time(); downs: List[float] = []
    while time.time() - t0 < seconds:
        for d in list(devs):
            try:
                ev = d.read_one()
                while ev:
                    if ev.type == ecodes.EV_KEY and ev.value == 1:
                        downs.append(ev.timestamp())
                    ev = d.read_one()
            except BlockingIOError:
                pass
            except Exception:
                try: devs.remove(d)
                except ValueError: pass
        time.sleep(0.01)
    if len(downs) < 2:
        return {"mean_ms": np.nan, "std_ms": np.nan, "count": len(downs)}
    diffs = np.diff(downs)
    return {"mean_ms": float(np.mean(diffs) * 1000.0),
            "std_ms":  float(np.std(diffs)  * 1000.0),
            "count":   int(len(downs))}

# -------------------- Reporting --------------------
def write_report(meta: Dict[str, object], feats: Dict[str, object],
                 proba: float, verdict: str, keystroke: Dict[str, object],
                 action: str, report_dir: str = REPORT_DIR) -> str:
    os.makedirs(report_dir, exist_ok=True)
    ts = time.strftime("%Y%m%d-%H%M%S")
    vid, pid = meta.get("vid"), meta.get("pid")
    fname = f"report_{ts}_{vid:04x}_{pid:04x}.txt" if isinstance(vid, int) and isinstance(pid, int) else f"report_{ts}.txt"
    path = os.path.join(report_dir, fname)
    lines = []
    lines.append(f"Timestamp: {ts}")
    lines.append(f"Device: VID:PID {meta.get('vidpid','')}  Bus {meta.get('bus')} Addr {meta.get('addr')}")
    lines.append(f"Manufacturer: {meta.get('manufacturer','Unknown')}")
    lines.append(f"Product     : {meta.get('product','Unknown')}")
    lines.append(f"Serial      : {meta.get('serial','')}")
    lines.append(f"bMaxPower mA: {meta.get('bMaxPower_mA')}")
    lines.append("")
    lines.append("Host context:")
    lines.append(f"  CPU avg percent: {feats.get('cpu avg percent')}")
    lines.append(f"  Process count  : {feats.get('process count')}")
    lines.append(f"  Avg proc runtime sec: {feats.get('avg process runtime sec')}")
    lines.append("")
    lines.append("Keystroke timing:")
    lines.append(f"  Events: {keystroke.get('count')}")
    lines.append(f"  Mean inter-keydown (ms): {keystroke.get('mean_ms')}")
    lines.append(f"  Std inter-keydown  (ms): {keystroke.get('std_ms')}")
    lines.append("")
    lines.append("Model verdict:")
    lines.append(f"  Probability(malicious): {proba:.4f}")
    lines.append(f"  Verdict              : {verdict}")
    lines.append("")
    lines.append(f"Action taken: {action}")
    with open(path, "w") as f:
        f.write("\n".join(lines))
    return path

# -------------------- CAPTCHA & popups --------------------
def random_captcha(n=CAPTCHA_LEN):
    import secrets
    alphabet = string.ascii_uppercase + string.digits
    return "".join(secrets.choice(alphabet) for _ in range(n))

class CaptchaDialog:
    def __init__(self, parent, title: str, code: str, tries: int = 3):
        self.code = code; self.tries_left = tries; self.ok = False
        self.win = tk.Toplevel(parent)
        self.win.title(title); self.win.geometry("360x200"); self.win.resizable(False, False)
        ttk.Label(self.win, text="Human check", font=("Segoe UI", 12, "bold")).pack(pady=10)
        self.code_var = tk.StringVar(value=self.code)
        ttk.Label(self.win, textvariable=self.code_var, font=("Consolas", 18, "bold")).pack(pady=5)
        ttk.Label(self.win, text="Type the code above:").pack(pady=(10, 2))
        self.entry = ttk.Entry(self.win, font=("Consolas", 12), justify="center"); self.entry.pack(padx=20); self.entry.focus_set()
        self.info_var = tk.StringVar(value=f"Tries left: {self.tries_left}")
        ttk.Label(self.win, textvariable=self.info_var, foreground="#666").pack(pady=6)
        f = ttk.Frame(self.win); f.pack(pady=6)
        ttk.Button(f, text="Submit", command=self.submit).grid(row=0, column=0, padx=8)
        ttk.Button(f, text="Cancel", command=self.cancel).grid(row=0, column=1, padx=8)
        self.win.protocol("WM_DELETE_WINDOW", self.cancel)
        self.win.transient(parent); self.win.grab_set()

    def submit(self):
        if self.entry.get().strip() == self.code:
            self.ok = True; self.win.destroy()
        else:
            self.tries_left -= 1
            if self.tries_left <= 0:
                messagebox.showerror("Verification failed", "No tries left."); self.win.destroy(); return
            self.info_var.set(f"Wrong code. Tries left: {self.tries_left}"); self.entry.delete(0, tk.END)

    def cancel(self): self.ok = False; self.win.destroy()
    def run(self, parent): parent.wait_window(self.win); return self.ok

def show_popup(parent, title: str, body: str, color: Optional[str] = None):
    win = tk.Toplevel(parent); win.title(title); win.geometry("520x280"); win.resizable(False, False)
    ttk.Label(win, text=title, font=("Segoe UI", 13, "bold")).pack(pady=(12, 6))
    lbl = ttk.Label(win, text=body, font=("Segoe UI", 11), wraplength=480, justify="left")
    if color:
        try: lbl.configure(foreground=color)
        except Exception: pass
    lbl.pack(padx=12, pady=8)
    ttk.Button(win, text="OK", command=win.destroy).pack(pady=10)
    win.transient(parent); win.grab_set(); parent.wait_window(win)

# -------------------- Dashboard App --------------------
BLOCKED_RECORDS: List[Dict[str, object]] = []

class App:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("USB Guard Dashboard")
        self.root.geometry("1000x600"); self.root.minsize(920, 560)

        if not IS_LINUX or not linux_is_root():
            messagebox.showwarning("Warning", "Strict blocking requires Linux + sudo. Dashboard will still run.")
        else:
            set_authorized_default_zero()

        self.model_bundle = load_or_train_model()

        # Top stats
        stats = ttk.Frame(self.root, padding=8); stats.pack(side=tk.TOP, fill=tk.X)
        self.cpu_var = tk.StringVar(value="CPU: -- %")
        self.proc_var = tk.StringVar(value="Processes: --")
        ttk.Label(stats, textvariable=self.cpu_var,  font=("Segoe UI", 11, "bold")).pack(side=tk.LEFT, padx=(4,16))
        ttk.Label(stats, textvariable=self.proc_var, font=("Segoe UI", 11)).pack(side=tk.LEFT)

        btnf = ttk.Frame(stats); btnf.pack(side=tk.RIGHT)
        ttk.Button(btnf, text="Show Blocked Devices", command=self.show_blocked).pack(side=tk.RIGHT, padx=6)
        ttk.Button(btnf, text="Refresh Now", command=self.refresh_all).pack(side=tk.RIGHT, padx=6)
        self.btn_allow  = ttk.Button(btnf, text="Approve Selected", command=self.on_allow);  self.btn_allow.pack(side=tk.RIGHT, padx=6)
        self.btn_block  = ttk.Button(btnf, text="Block Selected",   command=self.on_block);  self.btn_block.pack(side=tk.RIGHT, padx=6)

        # Table
        tablef = ttk.Frame(self.root, padding=8); tablef.pack(side=tk.TOP, fill=tk.BOTH, expand=True)
        cols = ("status", "vidpid", "bus", "addr", "manufacturer", "product", "serial", "power")
        self.tree = ttk.Treeview(tablef, columns=cols, show="headings", height=18)
        for c, t in zip(cols, ["Status", "VID:PID", "Bus", "Addr", "Manufacturer", "Product", "Serial", "bMaxPower (mA)"]):
            self.tree.heading(c, text=t)
        self.tree.column("status", width=110, anchor=tk.CENTER)
        self.tree.column("vidpid", width=120, anchor=tk.CENTER)
        self.tree.column("bus",    width=60,  anchor=tk.CENTER)
        self.tree.column("addr",   width=60,  anchor=tk.CENTER)
        self.tree.column("manufacturer", width=180)
        self.tree.column("product",      width=200)
        self.tree.column("serial",       width=210)
        self.tree.column("power",        width=130, anchor=tk.CENTER)
        vsb = ttk.Scrollbar(tablef, orient="vertical", command=self.tree.yview)
        hsb = ttk.Scrollbar(tablef, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscroll=vsb.set, xscroll=hsb.set)
        self.tree.grid(row=0, column=0, sticky="nsew"); vsb.grid(row=0, column=1, sticky="ns"); hsb.grid(row=1, column=0, sticky="ew")
        tablef.rowconfigure(0, weight=1); tablef.columnconfigure(0, weight=1)

        self.status_var = tk.StringVar(value="Ready")
        ttk.Label(self.root, textvariable=self.status_var, relief=tk.SUNKEN, anchor="w").pack(side=tk.BOTTOM, fill=tk.X)

        self.devices: List[Dict[str, object]] = []
        self.event_q: Queue = Queue()

        # udev observer for immediate block + per-device CAPTCHA + ML
        self._start_udev_observer()

        # periodic refresh
        self.refresh_all()
        self.root.after(DASH_REFRESH_MS, self._periodic)

    # ---- udev observer ----
    def _udev_callback(self, device):
        """pyudev MonitorObserver passes only 'device'. Use device.action."""
        try:
            # Only react to new usb_device (not interfaces)
            if device.subsystem != "usb": return
            if getattr(device, "device_type", None) not in (None, "usb_device"):  # some udevs set None
                return
            action = getattr(device, "action", None)
            if action != "add": return

            # Attributes can be in attributes or properties depending on distro/udev
            def _attr(name, default=None):
                try: return device.attributes.asstring(name)
                except Exception:
                    return default

            bus_s  = _attr("busnum")
            dev_s  = _attr("devnum")
            vid_s  = _attr("idVendor")  or device.properties.get("ID_VENDOR_ID")
            pid_s  = _attr("idProduct") or device.properties.get("ID_MODEL_ID")

            if not (bus_s and dev_s and vid_s and pid_s):
                return

            bus  = int(bus_s)
            addr = int(dev_s)
            vid  = int(str(vid_s), 16)
            pid  = int(str(pid_s), 16)

            # Immediately force unauthorized (extra safety even with authorized_default=0)
            auth_path = os.path.join(device.sys_path, "authorized")
            try:
                if os.path.exists(auth_path):
                    with open(auth_path, "w") as f:
                        f.write("0\n")
                    logging.info("udev: deauthorized %s", device.sys_path)
            except Exception as e:
                logging.warning("udev: failed to deauthorize %s: %s", device.sys_path, e)

            # enqueue for UI processing (CAPTCHA -> authorize -> ML)
            self.event_q.put({"bus": bus, "addr": addr, "vid": vid, "pid": pid})
        except Exception as e:
            logging.exception("udev callback error: %s", e)

    def _start_udev_observer(self):
        if not (IS_LINUX and linux_is_root()):
            logging.warning("Not Linux or not root; strict gate will not fully apply.")
            return
        # Ensure new devices start unauthorized when possible
        set_authorized_default_zero()

        context  = pyudev.Context()
        monitor  = pyudev.Monitor.from_netlink(context)
        monitor.filter_by(subsystem="usb")  # get only USB events
        # Use MonitorObserver; callback receives 'device' ONLY (fix for your crash)
        observer = pyudev.MonitorObserver(monitor, callback=self._udev_callback, name="usb-guard-observer")
        observer.daemon = True
        observer.start()
        logging.info("udev observer started.")

    # ---- UI helpers ----
    def _get_selected_device(self) -> Optional[Dict[str, object]]:
        sel = self.tree.selection()
        if not sel: return None
        idx = self.tree.index(sel[0])
        if 0 <= idx < len(self.devices):
            return self.devices[idx]
        return None

    def on_block(self):
        dev = self._get_selected_device()
        if not dev:
            messagebox.showinfo("Select a device", "Select a device first."); return
        bus, addr = dev.get("bus"), dev.get("addr")
        if IS_LINUX and linux_is_root() and bus is not None and addr is not None:
            if linux_set_authorized(bus, addr, False):
                rec = dict(dev); rec["when"] = time.strftime("%Y-%m-%d %H:%M:%S"); BLOCKED_RECORDS.append(rec)
                self.status_var.set(f"Blocked {dev.get('vidpid','')}")
        else:
            messagebox.showwarning("Not supported", "Blocking needs Linux + sudo.")
        self.refresh_all()

    def on_allow(self):
        dev = self._get_selected_device()
        if not dev:
            messagebox.showinfo("Select a device", "Select a device first."); return
        bus, addr = dev.get("bus"), dev.get("addr")
        if IS_LINUX and linux_is_root() and bus is not None and addr is not None:
            if linux_set_authorized(bus, addr, True):
                self.status_var.set(f"Approved {dev.get('vidpid','')}")
        else:
            messagebox.showwarning("Not supported", "Approve needs Linux + sudo.")
        self.refresh_all()

    def show_blocked(self):
        win = tk.Toplevel(self.root); win.title("Blocked Devices"); win.geometry("820x400")
        cols = ("when", "vidpid", "manufacturer", "product", "serial", "bus", "addr")
        tv = ttk.Treeview(win, columns=cols, show="headings")
        for c, t in zip(cols, ["When", "VID:PID", "Manufacturer", "Product", "Serial", "Bus", "Addr"]):
            tv.heading(c, text=t)
        for c,w in [("when",150),("vidpid",120),("manufacturer",170),("product",220),("serial",200),("bus",60),("addr",60)]:
            tv.column(c, width=w, anchor=tk.CENTER if c in ("when","vidpid","bus","addr") else tk.W)
        vsb = ttk.Scrollbar(win, orient="vertical", command=tv.yview); tv.configure(yscroll=vsb.set)
        tv.pack(side=tk.LEFT, fill=tk.BOTH, expand=True); vsb.pack(side=tk.RIGHT, fill=tk.Y)
        for rec in BLOCKED_RECORDS:
            tv.insert("", tk.END, values=(rec.get("when",""), rec.get("vidpid",""), rec.get("manufacturer","Unknown"),
                                          rec.get("product","Unknown"), rec.get("serial",""),
                                          rec.get("bus",""), rec.get("addr","")))

    # ---- periodic/UI refresh & event consumption ----
    def refresh_all(self):
        cpu, procs = get_host_stats()
        self.cpu_var.set(f"CPU: {cpu:.1f} %"); self.proc_var.set(f"Processes: {procs}")
        self.devices = list_usb_devices()
        for i in self.tree.get_children(): self.tree.delete(i)
        for dev in self.devices:
            status = "Unknown"
            if dev.get("authorized") is True:  status = "Authorized"
            elif dev.get("authorized") is False: status = "Blocked"
            pwr = dev.get("bMaxPower_mA"); pwr_str = f"{pwr}" if isinstance(pwr, int) else "-"
            self.tree.insert("", tk.END, values=(status, dev.get("vidpid",""), dev.get("bus",""), dev.get("addr",""),
                                                 dev.get("manufacturer","Unknown"), dev.get("product","Unknown"),
                                                 dev.get("serial",""), pwr_str))
        self.status_var.set(f"Found {len(self.devices)} USB device(s).")

    def _periodic(self):
        try:
            while True:
                ev = self.event_q.get_nowait()
                self._handle_new_device_event(ev)
        except Empty:
            pass
        except Exception as e:
            logging.exception("Event handling error: %s", e)
        finally:
            try: self.refresh_all()
            except Exception as e:
                logging.exception("Periodic refresh error: %s", e)
                self.status_var.set(f"Error: {e}")
            self.root.after(DASH_REFRESH_MS, self._periodic)

    # ---- Core per-device handling (CAPTCHA -> authorize -> ML -> block/report if malicious) ----
    def _wait_for_pyusb_device(self, bus: int, addr: int, timeout: float = 6.0):
        t0 = time.time()
        while time.time() - t0 < timeout:
            for d in usb.core.find(find_all=True):
                if getattr(d, "bus", None) == bus and getattr(d, "address", None) == addr:
                    return d
            time.sleep(0.1)
        return None

    def _handle_new_device_event(self, ev: Dict[str, object]):
        bus, addr, vid, pid = ev["bus"], ev["addr"], ev["vid"], ev["pid"]

        # Per-device CAPTCHA (device is blocked at this point)
        code = random_captcha()
        ok = CaptchaDialog(self.root, f"Authorize {vid:04x}:{pid:04x}", code, tries=CAPTCHA_TRIES).run(self.root)
        if not ok:
            self.status_var.set(f"CAPTCHA failed for {vid:04x}:{pid:04x}; kept blocked.")
            # record as blocked
            BLOCKED_RECORDS.append({"when": time.strftime("%Y-%m-%d %H:%M:%S"), "vidpid": f"{vid:04x}:{pid:04x}",
                                    "manufacturer":"Unknown","product":"Unknown","serial":"","bus":bus,"addr":addr})
            return

        # Authorize now
        if IS_LINUX and linux_is_root() and bus is not None and addr is not None:
            linux_set_authorized(bus, addr, True)

        # Wait for PyUSB view of the now-authorized device
        dev = self._wait_for_pyusb_device(bus, addr, timeout=6.0)

        # Collect metadata
        meta = {"bus": bus, "addr": addr, "vid": vid, "pid": pid, "vidpid": f"{vid:04x}:{pid:04x}",
                "manufacturer":"Unknown","product":"Unknown","serial":"","bMaxPower_mA": None}
        try:
            if dev is not None:
                if getattr(dev, "iManufacturer", 0): meta["manufacturer"] = usb.util.get_string(dev, dev.iManufacturer) or "Unknown"
                if getattr(dev, "iProduct", 0):      meta["product"]      = usb.util.get_string(dev, dev.iProduct)      or "Unknown"
                if getattr(dev, "iSerialNumber", 0): meta["serial"]       = usb.util.get_string(dev, dev.iSerialNumber)  or ""
                try:
                    cfg = dev.get_active_configuration()
                    if hasattr(cfg, "bMaxPower"): meta["bMaxPower_mA"] = int(cfg.bMaxPower) * 2
                except Exception: pass
        except Exception: pass

        # Host context + keystroke timing
        cpu_pct, proc_cnt, avg_runtime = sample_cpu_and_processes()
        ks = monitor_keystrokes_for_device(vid, pid, KEY_OBS_SECONDS)

        # ML features
        row = {
            "vendor id": vid, "product id": pid,
            "manufacturer": meta["manufacturer"], "device description": meta["product"],
            "drive interface": "USB", "removable drive": 0,
            "usb speed": np.nan,
            "power mA": meta["bMaxPower_mA"] if meta["bMaxPower_mA"] is not None else np.nan,
            "cpu avg percent": cpu_pct, "process count": proc_cnt, "avg process runtime sec": avg_runtime,
            "keystroke mean ms": ks.get("mean_ms", np.nan), "keystroke std ms": ks.get("std_ms", np.nan),
            "sector count": np.nan, "source type": "Unknown", "ftk available": 0,
        }

        pred, proba = classify(self.model_bundle, row)
        verdict = "Malicious" if pred == 1 else "Benign"

        ks_suspicious = False
        if isinstance(ks.get("mean_ms"), (int, float)) and ks.get("count", 0) >= KEY_MIN_EVENTS:
            ks_suspicious = ks["mean_ms"] < KEY_MEAN_MS_MIN

        alert_msgs = []
        if verdict == "Malicious": alert_msgs.append(f"Model: Malicious (p={proba:.2f}).")
        if ks_suspicious:          alert_msgs.append(f"Keystroke mean {ks['mean_ms']:.1f} ms (< {KEY_MEAN_MS_MIN} ms).")

        if alert_msgs:
            # Re-block immediately
            action_taken = "Blocked (deauthorized)" if (IS_LINUX and linux_is_root()) else "Alert issued (no strict gate)"
            if IS_LINUX and linux_is_root(): linux_set_authorized(bus, addr, False)
            # Record + report + alert popup
            rec = dict(meta); rec["when"] = time.strftime("%Y-%m-%d %H:%M:%S"); BLOCKED_RECORDS.append(rec)
            report_path = write_report(meta, row, proba, "Malicious", ks, action_taken, REPORT_DIR)
            body = "ALERT: device blocked.\n\n" + "\n".join(alert_msgs) + f"\n\nReport saved to:\n{report_path}"
            show_popup(self.root, "USB Guard Alert", body, color="#e74c3c")
        else:
            body = (f"Device {meta['vidpid']} permitted.\n\n"
                    f"Model verdict: {verdict} (p={proba:.2f})\n"
                    f"Keystrokes: count={ks.get('count')}  mean={ks.get('mean_ms')} ms")
            show_popup(self.root, "USB Guard", body, color="#2ecc71")

        self.refresh_all()

# -------------------- Main --------------------
def main():
    if IS_LINUX and not linux_is_root():
        print("NOTE: Run with sudo for strict pre-CAPTCHA blocking (Linux sysfs).")
    root = tk.Tk()
    app = App(root)
    try:
        root.mainloop()
    except KeyboardInterrupt:
        print("\n[+] Exiting cleanly."); sys.exit(0)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n[+] Exiting cleanly."); sys.exit(0)
    except Exception as exc:
        print(f"Fatal error: {exc}")
        logging.exception("Fatal error: %s", exc)
        sys.exit(1)

